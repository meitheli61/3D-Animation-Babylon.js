var CurrentAnimation;
var animationTime = [];
var m_bStartMovingSlider = false;
var moveSliderTimeout;
var hero;